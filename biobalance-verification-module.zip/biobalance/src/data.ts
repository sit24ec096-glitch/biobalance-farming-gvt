// Prototype/demo data only. Not real government statistics.
export type Cat = 'Balanced' | 'Biodiversity improving' | 'Economically strong' | 'Needs attention';
export type Ver = 'Verified' | 'Pending' | 'Rejected';
export interface Farm { id: string; place: string; region: string; acres: number; eco: number; bio: number; score: number; credits: number; change: number; ver: Ver; incentive: string; cat: Cat; }

export const CATS: Cat[] = ['Balanced', 'Biodiversity improving', 'Economically strong', 'Needs attention'];
export const CAT_COLOR: Record<Cat, string> = { Balanced: '#15803d', 'Biodiversity improving': '#eab308', 'Economically strong': '#2563eb', 'Needs attention': '#dc2626' };
export const REGIONS = ['Maharashtra', 'Karnataka', 'Tamil Nadu', 'Punjab', 'Gujarat', 'Madhya Pradesh', 'Uttar Pradesh'];
export const inr = (n: number) => '₹' + n.toLocaleString('en-IN');

const catOf = (e: number, b: number, ch: number): Cat =>
  e >= 65 && b >= 65 ? 'Balanced' : b < 65 && ch >= 15 ? 'Biodiversity improving' : e >= 65 ? 'Economically strong' : 'Needs attention';
const incentiveOf = (score: number, ver: Ver) =>
  ver !== 'Verified' ? 'Verification pending' : score >= 85 ? 'High-performance support' : score >= 70 ? 'Enhanced support' : score >= 50 ? 'Basic support' : 'Needs support';

const mk = (id: string, place: string, region: string, acres: number, eco: number, bio: number, credits: number, change: number, ver: Ver): Farm => {
  const score = Math.round((eco + bio) / 2);
  return { id, place, region, acres, eco, bio, score, credits, change, ver, incentive: incentiveOf(score, ver), cat: catOf(eco, bio, change) };
};

// Registry sample (10–15 farmers across India)
export const REGISTRY: Farm[] = [
  mk('BB-1025', 'Pune', 'Maharashtra', 4.5, 81, 74, 182, 26, 'Verified'),
  mk('BB-1182', 'Nashik', 'Maharashtra', 3.2, 70, 58, 96, 14, 'Pending'),
  mk('BB-1240', 'Mysuru', 'Karnataka', 6.0, 77, 82, 214, 22, 'Verified'),
  mk('BB-1311', 'Dharwad', 'Karnataka', 2.8, 52, 61, 88, 18, 'Verified'),
  mk('BB-1407', 'Coimbatore', 'Tamil Nadu', 5.1, 84, 79, 201, 19, 'Verified'),
  mk('BB-1466', 'Thanjavur', 'Tamil Nadu', 3.9, 58, 47, 54, 6, 'Verified'),
  mk('BB-1533', 'Ludhiana', 'Punjab', 9.5, 90, 55, 120, 9, 'Verified'),
  mk('BB-1598', 'Amritsar', 'Punjab', 7.4, 72, 63, 110, 12, 'Pending'),
  mk('BB-1640', 'Anand', 'Gujarat', 4.0, 79, 71, 158, 17, 'Verified'),
  mk('BB-1712', 'Indore', 'Madhya Pradesh', 8.2, 68, 66, 143, 15, 'Verified'),
  mk('BB-1789', 'Sagar', 'Madhya Pradesh', 2.5, 46, 52, 61, 11, 'Rejected'),
  mk('BB-1856', 'Lucknow', 'Uttar Pradesh', 3.6, 63, 69, 132, 21, 'Verified'),
  mk('BB-1904', 'Varanasi', 'Uttar Pradesh', 2.2, 49, 44, 40, 5, 'Verified'),
];

// Deterministic pseudo-random scatter points
let seed = 7;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
export const FARMS: Farm[] = [...REGISTRY, ...Array.from({ length: 130 }, (_, i) => {
  const eco = Math.round(35 + rnd() * 60), bio = Math.round(30 + rnd() * 65), ch = Math.round(rnd() * 30 - 2);
  return mk(`BB-${2000 + i}`, REGIONS[i % 7], REGIONS[i % 7], Math.round((2 + rnd() * 8) * 10) / 10, eco, bio, Math.round(bio * 2.2), ch, rnd() > 0.15 ? 'Verified' : 'Pending');
})];

export const PRACTICES = [
  { name: 'Crop diversification', pts: 10 }, { name: 'Intercropping', pts: 10 }, { name: 'Flower/pollinator habitat', pts: 8 },
  { name: 'Native vegetation', pts: 15 }, { name: 'Crop rotation', pts: 10 }, { name: 'Water-efficient irrigation', pts: 8 },
  { name: 'Reduced chemical dependency', pts: 10 },
];
export const ROI = [
  { name: 'Flower Strip', cost: 2000, credits: 10, roi: '5' }, { name: 'Native Vegetation', cost: 5000, credits: 15, roi: '3' }, { name: 'Cover Crop', cost: 1500, credits: 8, roi: '5.3' },
];
export const VERIFICATIONS = [
  { farmer: 'BB-1025', practice: 'Pollinator habitat', evidence: 'Photo + location', status: 'Verified' as Ver, credits: 8 },
  { farmer: 'BB-1182', practice: 'Native vegetation', evidence: 'Pending review', status: 'Pending' as Ver, credits: 15 },
  { farmer: 'BB-1240', practice: 'Crop rotation', evidence: 'Field log + photo', status: 'Verified' as Ver, credits: 10 },
  { farmer: 'BB-1598', practice: 'Water-efficient irrigation', evidence: 'Invoice + photo', status: 'Pending' as Ver, credits: 8 },
  { farmer: 'BB-1789', practice: 'Intercropping', evidence: 'Photo unclear', status: 'Rejected' as Ver, credits: 0 },
];
export const PERIODS = { 'Current Season': { f: 1, d: 0 }, 'Previous Season': { f: 0.92, d: -3.1 }, 'Year to Date': { f: 1.6, d: -1.2 } } as const;
export type Period = keyof typeof PERIODS;
const avg = (a: number[]) => a.reduce((s, x) => s + x, 0) / (a.length || 1);

/** Aggregates for a set of farms. Headline values are anchored to the brief's figures and shifted by region/period. */
export function kpis(region: string, period: Period) {
  const sub = region === 'All India' ? FARMS : FARMS.filter(f => f.region === region);
  const p = PERIODS[period], share = sub.length / FARMS.length;
  const shift = (k: 'score' | 'bio') => avg(sub.map(f => f[k])) - avg(FARMS.map(f => f[k]));
  return {
    sub, farms: Math.round(12548 * share * (period === 'Previous Season' ? 0.92 : 1)),
    score: +(74.6 + shift('score') + p.d).toFixed(1), bio: Math.round(76 + shift('bio') + p.d),
    credits: Math.round(936420 * share * p.f), viable: +(89.2 + (avg(sub.map(f => f.eco)) - avg(FARMS.map(f => f.eco))) / 4).toFixed(1),
    pool: +(18.6 * share * p.f).toFixed(1),
  };
}
export const REGION_STATS = REGIONS.map(r => {
  const s = FARMS.filter(f => f.region === r), farms = Math.round(12548 * s.length / FARMS.length);
  return { region: r, farms, score: Math.round(avg(s.map(f => f.score))), bio: Math.round(avg(s.map(f => f.bio))), eco: Math.round(avg(s.map(f => f.eco))),
    credits: Math.round(avg(s.map(f => f.credits))), change: Math.round(avg(s.map(f => f.change))), need: +(farms * 0.67 * 22100 / 1e7).toFixed(2) };
});
