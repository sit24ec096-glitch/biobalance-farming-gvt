import { useState } from 'react';
import { CartesianGrid, Legend, ReferenceArea, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis } from 'recharts';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from './components/ui';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGISTRY, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from './data';

const FLOW = ['Farmer data', 'Economic + biodiversity analysis', 'BioBalance score', 'Verified credits', 'Government insights', 'Targeted support / incentives'];
type K = ReturnType<typeof kpis>;

const Tip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const f: Farm = payload[0].payload;
  return <div className="rounded-lg bg-white p-2 text-xs shadow ring-1 ring-stone-200"><b>{f.id}</b> · {f.region}<br />Economic {f.eco} · Biodiversity {f.bio}<br />BioBalance {f.score} · Credits {f.credits}</div>;
};
export const Scatterplot = ({ farms }: { farms: Farm[] }) => (
  <Card title="Economic Viability vs Biodiversity">
    <ResponsiveContainer width="100%" height={380}>
      <ScatterChart margin={{ top: 10, right: 20, bottom: 25, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" dataKey="eco" domain={[30, 100]} label={{ value: 'Economic Viability Score', position: 'insideBottom', offset: -12 }} />
        <YAxis type="number" dataKey="bio" domain={[25, 100]} label={{ value: 'Biodiversity Score', angle: -90, position: 'insideLeft' }} />
        <ReferenceArea x1={65} x2={100} y1={65} y2={100} fill="#16a34a" fillOpacity={0.1} stroke="#16a34a" strokeDasharray="4 4" label={{ value: 'BioBalance Zone', fill: '#166534', fontSize: 12 }} />
        <Tooltip content={<Tip />} /><Legend verticalAlign="top" />
        {CATS.map(c => <Scatter key={c} name={c} data={farms.filter(f => f.cat === c)} fill={CAT_COLOR[c]} />)}
      </ScatterChart>
    </ResponsiveContainer>
  </Card>
);

export function Dashboard({ k }: { k: K }) {
  const insights = [
    [<Leaf />, 'Biodiversity opportunity', '12% of participating farms have low biodiversity scores but remain economically viable, indicating potential for targeted ecological interventions.'],
    [<Droplets />, 'Resource opportunity', 'Water-efficient practices are associated with improved resource scores in the current prototype dataset.'],
    [<Coins />, 'Credit growth', 'Verified BioBalance Credits increased 14.8% compared with the previous monitoring period.'],
    [<ShieldAlert />, 'Support required', '1,248 farms are currently below their selected livelihood threshold and may require technical or financial support.'],
  ];
  return (<div className="space-y-6">
    <Card><div className="flex flex-wrap items-center gap-1 text-sm font-semibold text-green-900">
      {FLOW.map((s, i) => <span key={s} className="flex items-center gap-1"><span className="rounded-full bg-green-100 px-3 py-1">{s}</span>{i < FLOW.length - 1 && <ChevronRight size={16} className="text-green-600" />}</span>)}
    </div><p className="mt-2 text-xs text-stone-500">Measure → Understand → Support → Improve</p><p className="mt-1 text-xs text-stone-500">Officials see only verified, summarized data received through the cloud, not the farmer's full application. All figures are mock prototype data; this is not an existing government system.</p></Card>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      <Kpi icon={<Wheat size={18} />} label="Participating Farms" value={k.farms.toLocaleString('en-IN')} sub="+8.4% this season" />
      <Kpi icon={<Scale size={18} />} label="Average BioBalance Score" value={`${k.score} / 100`} sub="▲ trending up vs baseline" bar={k.score} />
      <Kpi icon={<Coins size={18} />} label="Verified BioBalance Credits" value={k.credits.toLocaleString('en-IN')} sub="Across all participating farms" />
      <Kpi icon={<Sprout size={18} />} label="Average Biodiversity Score" value={`${k.bio} / 100`} sub="Progress toward 100" bar={k.bio} />
      <Kpi icon={<Wallet size={18} />} label="Economically Viable Farms" value={`${k.viable}%`} sub="Above selected livelihood threshold" />
      <Kpi icon={<CreditCard size={18} />} label="Proposed Incentive Pool" value={`₹${k.pool} Cr`} sub="Prototype estimate" />
    </div>
    <Scatterplot farms={k.sub} />
    <Card title="Government Insights"><div className="grid gap-3 md:grid-cols-2">
      {insights.map(([ic, t, b], i) => <div key={i} className="rounded-xl bg-green-50 p-4"><div className="mb-1 flex items-center gap-2 font-semibold text-green-900">{ic}{t as string}</div><p className="text-sm">{b as string}</p></div>)}
    </div><Disclaimer>Insights are generated from the mock dataset, not real government statistics.</Disclaimer></Card>
  </div>);
}

export function Farmers({ farms, onOpen }: { farms: Farm[]; onOpen: (f: Farm) => void }) {
  const H = ['Farmer ID', 'Region', 'Farm Size', 'Economic', 'Biodiversity', 'BioBalance', 'Credits', 'Change', 'Verification', 'Incentive Status'];
  return (<Card title="Farmer Sustainability Registry"><div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm">
    <thead><tr className="border-b text-stone-500">{H.map(h => <th key={h} className="py-2 pr-3 font-semibold">{h}</th>)}</tr></thead>
    <tbody>{farms.map(f => (
      <tr key={f.id} tabIndex={0} onKeyDown={e => e.key === 'Enter' && onOpen(f)} onClick={() => onOpen(f)} className="cursor-pointer border-b border-stone-100 hover:bg-green-50">
        <td className="py-2 font-semibold">{f.id}</td><td>{f.place}</td><td>{f.acres} acres</td><td>{f.eco}</td><td>{f.bio}</td><td>{f.score}</td><td>{f.credits}</td>
        <td className="text-green-700">+{f.change}</td><td><Badge tone={verTone(f.ver)}>{f.ver === 'Verified' ? '✓ Verified' : f.ver}</Badge></td><td><Badge tone={incTone(f.incentive)}>{f.incentive}</Badge></td>
      </tr>))}</tbody></table></div><p className="mt-2 text-xs text-stone-500">Select a row to open the farmer detail.</p></Card>);
}

export function Credits() {
  return (<div className="space-y-6">
    <Card title="BioBalance Credits">
      <p className="mb-4 text-sm">Credits represent the verified contribution of a farm toward biodiversity-friendly and resource-efficient agriculture.</p>
      {PRACTICES.map(p => <div key={p.name} className="mb-2 grid grid-cols-[1fr_2fr_3rem] items-center gap-3 text-sm"><span>{p.name}</span><ScoreBar value={p.pts * 6} /><b className="text-green-800">+{p.pts}</b></div>)}
      <Disclaimer>Credit values shown are prototype weights for demonstration and would require agricultural/ecological validation before real-world deployment.</Disclaimer>
    </Card>
    <Card title="Biodiversity ROI">
      <p className="mb-3 text-sm">Measures the relative biodiversity benefit obtained for the additional economic resources invested in ecological interventions.</p>
      <div className="grid gap-3 md:grid-cols-3">{ROI.map(r => <div key={r.name} className="rounded-xl bg-green-50 p-4"><div className="font-semibold text-green-900">{r.name}</div>
        <div className="text-sm">Additional cost: {inr(r.cost)}</div><div className="text-sm">Benefit: +{r.credits} credits</div><div className="mt-1 font-display text-lg text-green-800">{r.roi} credits / ₹1,000</div></div>)}</div>
      <Disclaimer>Prototype calculations for demonstration only.</Disclaimer>
    </Card></div>);
}

export function Incentives({ onNav }: { onNav: (p: string) => void }) {
  const tiers = [['50–69 BioBalance', 'Basic support'], ['70–84', 'Enhanced support'], ['85–100', 'High-performance support']];
  return (<Card title="Incentive Program">
    <div className="grid gap-3 sm:grid-cols-3">{[['Total eligible farms', '8,426'], ['Potential incentive requirement', '₹18.6 Cr'], ['Average proposed support', '₹22,100']].map(([l, v]) =>
      <div key={l} className="rounded-xl bg-green-50 p-4"><div className="text-xs text-stone-500">{l}</div><div className="font-display text-2xl text-green-900">{v}</div></div>)}</div>
    <div className="mt-4 space-y-2">{tiers.map(([a, b]) => <div key={a} className="flex justify-between rounded-lg bg-stone-50 p-3 text-sm"><span>{a}</span><b>{b}</b></div>)}</div>
    <Disclaimer>Prototype incentive framework — final eligibility and funding rules would be determined by the responsible government authority.</Disclaimer>
    <div className="mt-4 flex flex-wrap gap-2">
      <button className="rounded-lg bg-green-800 px-4 py-2 text-sm text-white" onClick={() => onNav('Farmers')}>Review Eligible Farms</button>
      <button className="rounded-lg border border-green-800 px-4 py-2 text-sm text-green-800" onClick={() => window.print()}>Export Report</button>
      <button className="rounded-lg border border-green-800 px-4 py-2 text-sm text-green-800" onClick={() => onNav('Regional Analysis')}>View Regional Allocation</button>
    </div></Card>);
}

export function Regional() {
  const [key, setKey] = useState<'score' | 'bio' | 'eco' | 'credits' | 'change'>('score');
  const rows = [...REGION_STATS].sort((a, b) => b[key] - a[key]);
  const opts = { score: 'BioBalance', bio: 'Biodiversity', eco: 'Economic viability', credits: 'Credits', change: 'Improvement from baseline' };
  return (<Card title="Regional Analysis">
    <label className="mb-3 flex items-center gap-2 text-sm">Sort by <select className="rounded-lg border px-2 py-1" value={key} onChange={e => setKey(e.target.value as typeof key)}>{Object.entries(opts).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
    <div className="grid gap-3 md:grid-cols-2">{rows.map(r => <div key={r.region} className="rounded-xl bg-green-50 p-4"><div className="font-display text-lg text-green-900">{r.region}</div>
      <div className="mt-1 grid grid-cols-2 gap-x-4 text-sm"><span>Farms: {r.farms.toLocaleString('en-IN')}</span><span>BioBalance: {r.score}</span><span>Biodiversity: {r.bio}</span><span>Economic: {r.eco}</span><span>Avg credits: {r.credits}</span><span>Need: ₹{r.need} Cr</span></div>
      <div className="mt-2"><ScoreBar value={r.score} /></div></div>)}</div></Card>);
}

export function Verification() {
  const [f, setF] = useState('All');
  const rows = VERIFICATIONS.filter(v => f === 'All' || v.status === f);
  return (<div className="space-y-6"><Card title="Verification Center">
    <div className="flex flex-wrap items-center gap-1 text-sm">{['Farmer submits evidence', 'Evidence review', 'Practice verification', 'Credits calculated', 'Cloud record updated'].map((s, i) =>
      <span key={s} className="flex items-center gap-1"><span className="rounded-full bg-green-100 px-3 py-1">{s}</span>{i < 4 && <ChevronRight size={14} />}</span>)}</div>
    <div className="my-4 flex gap-2">{['All', 'Verified', 'Pending', 'Rejected'].map(o => <button key={o} onClick={() => setF(o)} className={`rounded-full px-3 py-1 text-sm ${f === o ? 'bg-green-800 text-white' : 'bg-stone-100'}`}>{o}</button>)}</div>
    <div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left text-sm"><thead><tr className="border-b text-stone-500">{['Farmer', 'Practice', 'Evidence', 'Status', 'Credits'].map(h => <th key={h} className="py-2">{h}</th>)}</tr></thead>
      <tbody>{rows.map(v => <tr key={v.farmer + v.practice} className="border-b border-stone-100"><td className="py-2 font-semibold">{v.farmer}</td><td>{v.practice}</td><td>{v.evidence}</td><td><Badge tone={verTone(v.status)}>{v.status === 'Verified' ? '✓ Verified' : v.status === 'Pending' ? '⏳ Pending' : 'Rejected'}</Badge></td><td>+{v.credits}</td></tr>)}</tbody></table></div>
  </Card></div>);
}

export function Settings() {
  return (<Card title="Responsible Data Use"><ul className="list-disc space-y-2 pl-5 text-sm">
    {['Farmer data should be collected with appropriate consent.', 'Only necessary information should be shared with authorized government users.', 'Personal information should be protected.', 'Credit calculations should be explainable.', 'Farmers should be able to understand why they received a particular score.', 'The system should support government decisions rather than automatically making decisions about farmers.'].map(t => <li key={t}>{t}</li>)}
  </ul><p className="mt-4 text-sm text-stone-600">Neutral language is used throughout: High improvement, Stable, Needs support, Verification pending, Economically viable, Biodiversity improving.</p></Card>);
}
export { REGISTRY };
