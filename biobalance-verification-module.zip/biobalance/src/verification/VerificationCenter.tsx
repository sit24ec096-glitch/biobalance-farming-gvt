import { useState } from 'react';
import { ArrowLeft, Check, ChevronRight, Clock, Coins, MapPin, Satellite, ShieldAlert, ShieldCheck, Hourglass } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar } from '../components/ui';
import { FARMERS, Farmer, GPSVerificationResult, PracticeVerificationResult, Result, SatelliteAnalysisResult, Status, verificationService as svc } from './service';

const sTone = (s: Status) => (s === 'Verified' ? 'green' : s === 'Pending' ? 'amber' : 'red') as 'green' | 'amber' | 'red';
const rTone = (r: Result) => (r === 'Consistent' || r === 'Supported' ? 'green' : r === 'Not supported' ? 'red' : 'amber') as 'green' | 'amber' | 'red';
const dot = { ok: '🟢', warn: '🟡', bad: '🔴' };
const ACTION: Record<Status, string> = { Pending: 'Review', Verified: 'View', 'Evidence mismatch': 'Investigate', Rejected: 'View' };

/** Circular progress indicator for the verification confidence. */
const Ring = ({ value }: { value: number }) => {
  const c = 2 * Math.PI * 52, col = value >= 80 ? '#15803d' : value >= 60 ? '#d97706' : '#dc2626';
  return <svg viewBox="0 0 120 120" className="h-36 w-36"><circle cx="60" cy="60" r="52" fill="none" stroke="#e7e5e4" strokeWidth="10" />
    <circle cx="60" cy="60" r="52" fill="none" stroke={col} strokeWidth="10" strokeLinecap="round" strokeDasharray={`${c * value / 100} ${c}`} transform="rotate(-90 60 60)" />
    <text x="60" y="58" textAnchor="middle" className="fill-stone-800 text-3xl font-bold">{value}</text><text x="60" y="76" textAnchor="middle" className="fill-stone-500 text-[10px]">/ 100</text></svg>;
};
const Step = ({ label, done, active }: { label: string; done: boolean; active?: boolean }) => (
  <span className={`rounded-full px-4 py-2 text-sm font-semibold ${done ? 'bg-green-700 text-white' : active ? 'bg-amber-100 text-amber-900' : 'bg-stone-100 text-stone-500'}`}>{done ? '✓ ' : ''}{label}</span>);

function Detail({ f, onBack, onDecide }: { f: Farmer; onBack: () => void; onDecide: (s: Status) => void }) {
  const [gps, setGps] = useState<GPSVerificationResult>(); const [sat, setSat] = useState<SatelliteAnalysisResult>(); const [pr, setPr] = useState<PracticeVerificationResult>();
  const [busy, setBusy] = useState(false); const [dec, setDec] = useState<'approve' | 'more' | 'reject' | null>(null);
  const run = async () => { setBusy(true); setGps(await svc.verifyGPS({ farmerId: f.id })); setSat(await svc.analyzeSatellite({ farmerId: f.id })); setPr(await svc.verifyPractice({ farmerId: f.id })); setBusy(false); };
  const decide = (d: 'approve' | 'more' | 'reject') => { setDec(d); onDecide(d === 'approve' ? 'Verified' : d === 'reject' ? 'Rejected' : 'Pending'); };
  const final = !pr ? 0 : dec === 'reject' ? 0 : dec === 'approve' && pr.heldCredits === 0 ? pr.submittedCredits : pr.verifiedCredits;
  const veg = sat ? Math.abs(sat.vegDeclared - sat.vegEstimated) : 0;
  const checks = gps && sat ? [
    ['Farm area', `Declared ${f.acres} acres · GPS boundary ${gps.boundaryAcres} acres`, Math.abs(gps.boundaryAcres - f.acres) / f.acres < 0.1],
    ['Vegetation claim', `Declared ${sat.vegDeclared}% · Satellite estimate ${sat.vegEstimated}%`, veg <= 8],
    ['Location', gps.locationOk ? 'Submitted coordinates match farm registration' : 'Submitted coordinates differ significantly from registered location', gps.locationOk],
    ['Duplicate evidence', 'No duplicate photograph detected (mock check)', true]] as [string, string, boolean][] : [];
  const audit = ['Farmer submitted evidence', 'GPS validation completed', 'Satellite analysis completed', 'Evidence consistency calculated', dec ? `Officer decision: ${dec === 'approve' ? 'approved' : dec === 'more' ? 'more evidence requested' : 'claim rejected'}` : 'Government officer review pending'];
  const times = ['10:20', '10:22', '10:24', '10:25', '10:27'];
  return (<div className="space-y-6">
    <button onClick={onBack} className="flex items-center gap-1 text-sm text-green-800"><ArrowLeft size={16} />Back to submissions</button>
    <Card><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-2xl text-green-950">Farmer {f.id}</h2>
      <p className="text-sm text-stone-600">{f.acres} acres · {f.loc} · Submitted {f.date}</p></div><Badge tone={sTone(f.status)}>{f.status === 'Pending' ? 'Verification Pending' : f.status}</Badge></div>
      <div className="mt-4 flex flex-wrap items-center gap-1">{[['Claim', true], ['GPS', !!gps], ['Satellite', !!sat], ['Verification', !!pr], ['Credits', !!dec]].map(([l, d], i) =>
        <span key={l as string} className="flex items-center gap-1"><Step label={l as string} done={d as boolean} />{i < 4 && <ChevronRight size={16} className="text-stone-400" />}</span>)}</div></Card>

    <Card title="Farmer Submitted Information"><div className="grid gap-3 text-sm md:grid-cols-2">
      <div><b>Claimed practices</b><ul className="mt-1">{f.claims.map(c => <li key={c}>✓ {c}</li>)}</ul></div>
      <div className="space-y-1"><div><b>Claimed biodiversity credits:</b> {f.sub}</div><div><b>Declared farm area:</b> {f.acres} acres</div><div><b>Expected profit:</b> ₹{f.profit.toLocaleString('en-IN')}</div></div></div>
      <button disabled={busy || !!pr} onClick={run} className="mt-4 rounded-lg bg-green-800 px-5 py-2 text-sm font-semibold text-white disabled:opacity-50">{busy ? 'Verifying…' : pr ? 'Evidence verified' : 'Verify Evidence'}</button></Card>

    {gps && <Card title="📍 GPS Verification"><div className="grid gap-4 md:grid-cols-2">
      <svg viewBox="0 0 300 200" className="w-full rounded-xl bg-green-50 ring-1 ring-green-100">
        {[...Array(9)].map((_, i) => <line key={'v' + i} x1={i * 37.5} y1="0" x2={i * 37.5} y2="200" stroke="#d1e7d0" />)}{[...Array(6)].map((_, i) => <line key={'h' + i} x1="0" y1={i * 40} x2="300" y2={i * 40} stroke="#d1e7d0" />)}
        <polygon points="70,50 210,40 240,125 130,160 55,115" fill="#16a34a" fillOpacity=".3" stroke="#15803d" strokeWidth="2" /><circle cx="140" cy="100" r="5" fill="#15803d" />
        {!gps.locationOk && <><rect x="215" y="140" width="70" height="45" fill="none" stroke="#dc2626" strokeDasharray="4" /><text x="250" y="197" textAnchor="middle" fontSize="8" fill="#dc2626">registered location</text></>}
        <text x="10" y="192" fontSize="8" fill="#57534e">Placeholder boundary — not a real map</text></svg>
      <div className="space-y-1 text-sm"><div>Latitude: {gps.lat} · Longitude: {gps.lng}</div><div>Farm boundary: {gps.boundaryAcres} acres · GPS accuracy ±{gps.accuracyM} m</div>
        <div>{gps.locationOk ? '🟢 Location consistent' : '🔴 Location mismatch'}</div>
        <ul className="my-2">{gps.checks.map(c => <li key={c.label}>{c.ok ? '✓' : '✗'} {c.label}</li>)}</ul><b>GPS confidence: {gps.confidence}%</b></div></div></Card>}

    {sat && <Card title="🛰️ Satellite Evidence"><Badge tone="blue">Prototype satellite analysis — simulated data</Badge>
      <div className="mt-3 grid gap-4 lg:grid-cols-2">
        <svg viewBox="0 0 300 200" className="w-full rounded-xl"><rect width="300" height="200" fill="#4a6b35" />
          <rect x="20" y="20" width="90" height="70" fill="#3d5a2b" /><rect x="120" y="10" width="80" height="60" fill="#6b8a45" /><rect x="200" y="60" width="90" height="80" fill="#557a3a" /><rect x="30" y="110" width="110" height="70" fill="#7a9450" /><ellipse cx="220" cy="165" rx="30" ry="14" fill="#4b7f9c" />
          <polygon points="70,50 210,40 240,125 130,160 55,115" fill="none" stroke="#fff" strokeWidth="2" strokeDasharray="6 3" /><text x="8" y="192" fontSize="9" fill="#fff">SIMULATED · detected boundary</text></svg>
        <div className="space-y-2">{sat.observations.map(o => <div key={o.label} className="rounded-lg bg-stone-50 p-3 text-sm"><div className="flex justify-between font-semibold"><span>{o.label}</span><span>{dot[o.status]}</span></div>
          <div>Declared: {o.claim} · Estimate: {o.estimate}{o.diff !== '—' && ` · Difference: ${o.diff}`}</div><div className="text-xs text-stone-500">{o.note}</div></div>)}</div></div>
      <Disclaimer>Satellite imagery cannot prove every practice. Directly observable: boundary, vegetation coverage, tree presence, water bodies. Requires additional evidence: reduced chemical dependency, irrigation method, crop rotation history.</Disclaimer></Card>}

    {pr && <><Card title="Claim vs Evidence"><div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left text-sm"><thead><tr className="border-b text-stone-500">{['Farmer Claim', 'Farmer Evidence', 'GPS', 'Satellite', 'Result'].map(h => <th key={h} className="py-2">{h}</th>)}</tr></thead>
      <tbody>{pr.rows.map(r => <tr key={r.claim} className="border-b border-stone-100"><td className="py-2 font-semibold">{r.claim}</td><td>{r.evidence ? '✓' : '✗'}</td><td>{r.gps ? '✓' : '✗'}</td><td>{['✗', '~', '✓'][r.sat]}</td><td><Badge tone={rTone(r.result)}>{r.result}</Badge></td></tr>)}</tbody></table></div></Card>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Verification Confidence"><div className="flex items-center gap-4"><Ring value={pr.confidence} /><div className="flex-1 space-y-2 text-sm">{pr.breakdown.map(b => <div key={b.label}><div className="flex justify-between"><span>{b.label}</span><b>{b.value}%</b></div><ScoreBar value={b.value} /></div>)}</div></div>
          <Disclaimer>Prototype confidence score, not a legally valid verification result.</Disclaimer></Card>
        <Card title="⚠️ Evidence Consistency Checks"><div className="space-y-2 text-sm">{checks.map(([t, d, ok]) => <div key={t} className={`rounded-lg p-3 ${ok ? 'bg-green-50' : 'bg-rose-50'}`}><b>{ok ? '🟢' : '🔴'} {t}</b> — {d}{!ok && t !== 'Duplicate evidence' && <div className="text-xs text-stone-600">Evidence mismatch, not a finding of fraud. Possible causes: observation date, cloud cover, seasonal change, GPS/boundary error, satellite resolution, entry error.</div>}</div>)}</div></Card></div>

      <Card title="Verification Decision"><div className="grid grid-cols-3 gap-2 text-center text-sm"><div className="rounded-xl bg-stone-50 p-3">Submitted credits<div className="font-display text-2xl">{pr.submittedCredits}</div></div>
        <div className="rounded-xl bg-green-50 p-3">Verified credits<div className="font-display text-2xl text-green-800">{dec ? final : pr.verifiedCredits}</div></div><div className="rounded-xl bg-amber-50 p-3">Held<div className="font-display text-2xl text-amber-800">{pr.heldCredits}</div></div></div>
        {pr.heldCredits > 0 && <p className="mt-2 text-sm">Why not all {pr.submittedCredits}? {pr.heldCredits} credits require additional evidence. Credits are never accepted automatically.</p>}
        <div className="mt-3 flex flex-wrap gap-2"><button disabled={!!dec} onClick={() => decide('approve')} className="rounded-lg bg-green-800 px-4 py-2 text-sm text-white disabled:opacity-40">✓ Approve</button>
          <button disabled={!!dec} onClick={() => decide('more')} className="rounded-lg bg-amber-500 px-4 py-2 text-sm text-white disabled:opacity-40">⚠ Request More Evidence</button>
          <button disabled={!!dec} onClick={() => decide('reject')} className="rounded-lg bg-rose-600 px-4 py-2 text-sm text-white disabled:opacity-40">✕ Reject Claim</button></div></Card></>}

    <Card title="Verification Audit Trail"><ol className="space-y-2 border-l-2 border-green-200 pl-4 text-sm">{audit.slice(0, gps ? (dec ? 5 : pr ? 5 : sat ? 3 : 2) : 1).map((a, i) =>
      <li key={a}><span className="text-xs text-stone-500">{f.date.slice(0, 2)} Sep 2026, {times[i]}</span><div>{a}</div></li>)}</ol></Card>

    {dec && pr && <Card title="Verified BioBalance Record"><div className="mb-3 rounded-lg bg-green-100 p-2 text-center font-semibold text-green-900">Verified BioBalance Record Updated.</div>
      <div className="grid gap-2 text-sm sm:grid-cols-3">{[['Farmer', f.id], ['Economic Score', f.sc[0]], ['Biodiversity Score', f.sc[1]], ['Resource Score', f.sc[2]], ['Submitted Credits', pr.submittedCredits], ['Verified Credits', final], ['Verification Confidence', pr.confidence + '%']].map(([l, v]) =>
        <div key={l as string} className="rounded-lg bg-stone-50 p-2"><div className="text-xs text-stone-500">{l}</div><b>{v}</b></div>)}</div>
      <p className="mt-2 text-sm">Status: {dec === 'approve' ? '🟢 Verified' : dec === 'more' ? '🟡 Partially verified — more evidence requested' : '🔴 Claim rejected'}</p></Card>}
    <p className="text-xs text-stone-500">Privacy: Farm location and agricultural information are sensitive operational data. Access should be restricted to authorized users and used only for the stated program purposes.</p>
  </div>);
}

export default function VerificationCenter() {
  const [list, setList] = useState(FARMERS); const [sel, setSel] = useState<Farmer | null>(null);
  if (sel) return <Detail key={sel.id} f={sel} onBack={() => setSel(null)} onDecide={s => setList(l => l.map(x => x.id === sel.id ? { ...x, status: s } : x))} />;
  return (<div className="space-y-6">
    <div><h2 className="font-display text-2xl text-green-950">Farm Verification Center</h2><p className="text-sm text-stone-600">Review farmer-submitted sustainability claims using location and environmental evidence.</p></div>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><Kpi icon={<Hourglass size={18} />} label="Pending Verification" value="128" sub="Awaiting officer review" />
      <Kpi icon={<ShieldCheck size={18} />} label="Verified Farms" value="1,842" sub="Prototype figure" /><Kpi icon={<ShieldAlert size={18} />} label="Evidence Mismatch" value="37" sub="Needs follow-up, not a fraud finding" />
      <Kpi icon={<Coins size={18} />} label="Verification Success Rate" value="91.4%" sub="Prototype figure" bar={91.4} /></div>
    <Card title="Farmer Submissions"><div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm"><thead><tr className="border-b text-stone-500">{['Farmer ID', 'Farmer', 'Location', 'Farm Area', 'Submitted Practice', 'Credits', 'Verification', 'Action'].map(h => <th key={h} className="py-2">{h}</th>)}</tr></thead>
      <tbody>{list.map(f => <tr key={f.id} className="border-b border-stone-100"><td className="py-2 font-semibold">{f.id}</td><td>{f.name}</td><td>{f.loc}</td><td>{f.acres} acres</td><td>{f.practice}</td><td>+{f.sub}</td>
        <td><Badge tone={sTone(f.status)}>{f.status === 'Verified' ? '🟢 Verified' : f.status === 'Pending' ? '🟡 Pending' : '🔴 ' + f.status}</Badge></td>
        <td><button className="rounded-lg border border-green-800 px-3 py-1 text-green-800" onClick={() => setSel(f)}>{ACTION[f.status]}</button></td></tr>)}</tbody></table></div>
      <Disclaimer>Prototype demo: GPS and satellite results are simulated by MockVerificationService, not real observations.</Disclaimer></Card></div>);
}
