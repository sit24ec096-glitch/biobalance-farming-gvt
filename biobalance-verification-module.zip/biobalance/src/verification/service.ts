// ---------------------------------------------------------------------------
// Verification service layer. The UI only depends on `VerificationService`.
// Prototype: MockVerificationService returns SIMULATED data (not real satellite
// observations). Future: RealVerificationService calls YOUR backend
// (e.g. POST /api/verify/gps). Satellite provider keys must live only on that
// backend, never in this React app.
// ---------------------------------------------------------------------------
export type Status = 'Verified' | 'Pending' | 'Evidence mismatch' | 'Rejected';
export type Result = 'Consistent' | 'Supported' | 'Partially supported' | 'Requires additional evidence' | 'Not supported';

export interface GPSVerificationRequest { farmerId: string }
export interface GPSVerificationResult { lat: number; lng: number; boundaryAcres: number; accuracyM: number; confidence: number; locationOk: boolean; checks: { label: string; ok: boolean }[] }
export interface SatelliteAnalysisRequest { farmerId: string }
export interface SatObservation { label: string; claim: string; estimate: string; diff: string; status: 'ok' | 'warn' | 'bad'; note: string }
export interface SatelliteAnalysisResult { simulated: true; vegDeclared: number; vegEstimated: number; observations: SatObservation[] }
export interface PracticeVerificationRequest { farmerId: string }
export interface PracticeRow { claim: string; evidence: boolean; gps: boolean; sat: 0 | 1 | 2; result: Result }
export interface PracticeVerificationResult { rows: PracticeRow[]; breakdown: { label: string; value: number }[]; confidence: number; submittedCredits: number; verifiedCredits: number; heldCredits: number }

export interface VerificationService {
  verifyGPS(data: GPSVerificationRequest): Promise<GPSVerificationResult>;
  analyzeSatellite(data: SatelliteAnalysisRequest): Promise<SatelliteAnalysisResult>;
  verifyPractice(data: PracticeVerificationRequest): Promise<PracticeVerificationResult>;
}

export interface Farmer {
  id: string; name: string; loc: string; acres: number; practice: string; sub: number; ver: number; status: Status; date: string;
  claims: string[]; profit: number; sc: [number, number, number];
  lat: number; lng: number; bAc: number; acc: number; locOk: boolean; gpsC: number;
  vd: number; ve: number; td: number; te: number; cropEst: string; cropOk: boolean; waterOk: boolean;
  bd: [number, number, number, number]; conf: number; rows: [string, boolean, boolean, 0 | 1 | 2, Result][];
}
const D = '29 September 2026';
export const FARMERS: Farmer[] = [
  { id: 'BB-1025', name: 'Ravi Kumar', loc: 'Thanjavur, Tamil Nadu', acres: 4.5, practice: 'Pollinator habitat', sub: 33, ver: 28, status: 'Pending', date: D,
    claims: ['Crop diversification', 'Pollinator/flower strip', 'Crop rotation', 'Water-efficient irrigation'], profit: 64000, sc: [81, 74, 83],
    lat: 10.787, lng: 79.1378, bAc: 4.4, acc: 8, locOk: true, gpsC: 94, vd: 72, ve: 69, td: 0.6, te: 0.55, cropEst: '2–3 vegetation classes', cropOk: true, waterOk: true, bd: [94, 91, 84, 79], conf: 87,
    rows: [['4.5 acre farm', true, true, 2, 'Consistent'], ['Pollinator habitat', true, true, 2, 'Supported'], ['Native vegetation', true, true, 2, 'Supported'],
      ['Crop diversification', true, true, 1, 'Partially supported'], ['Water-efficient irrigation', true, true, 1, 'Requires additional evidence']] },
  { id: 'BB-1031', name: 'Meena Devi', loc: 'Pune, Maharashtra', acres: 6.2, practice: 'Crop diversification', sub: 28, ver: 28, status: 'Verified', date: '28 September 2026',
    claims: ['Crop diversification', 'Intercropping', 'Water-efficient irrigation'], profit: 71000, sc: [84, 77, 85],
    lat: 18.5204, lng: 73.8567, bAc: 6.1, acc: 6, locOk: true, gpsC: 96, vd: 65, ve: 63, td: 0.8, te: 0.78, cropEst: '3–4 vegetation classes', cropOk: true, waterOk: true, bd: [96, 95, 92, 90], conf: 93,
    rows: [['6.2 acre farm', true, true, 2, 'Consistent'], ['Crop diversification', true, true, 2, 'Supported'], ['Intercropping', true, true, 2, 'Supported']] },
  { id: 'BB-1057', name: 'Lakshmi Nair', loc: 'Coimbatore, Tamil Nadu', acres: 5, practice: 'Flower/pollinator habitat', sub: 26, ver: 16, status: 'Pending', date: D,
    claims: ['Flower/pollinator habitat', 'Crop rotation', 'Native vegetation'], profit: 52000, sc: [72, 61, 70],
    lat: 11.0168, lng: 76.9558, bAc: 4.8, acc: 12, locOk: true, gpsC: 88, vd: 80, ve: 52, td: 0.9, te: 0.5, cropEst: '1–2 vegetation classes', cropOk: false, waterOk: true, bd: [88, 86, 58, 64], conf: 68,
    rows: [['5 acre farm', true, true, 2, 'Consistent'], ['Flower/pollinator habitat', true, true, 1, 'Partially supported'], ['Native vegetation', true, true, 0, 'Not supported'], ['Crop rotation', true, true, 1, 'Requires additional evidence']] },
  { id: 'BB-1088', name: 'Arjun Singh', loc: 'Punjab', acres: 8, practice: 'Native vegetation', sub: 15, ver: 0, status: 'Evidence mismatch', date: D,
    claims: ['Native vegetation', 'Crop rotation'], profit: 88000, sc: [88, 55, 64],
    lat: 30.9, lng: 75.85, bAc: 6.9, acc: 45, locOk: false, gpsC: 31, vd: 70, ve: 41, td: 1.2, te: 0.3, cropEst: '1 vegetation class', cropOk: false, waterOk: false, bd: [31, 58, 45, 40], conf: 31,
    rows: [['8 acre farm', true, false, 1, 'Requires additional evidence'], ['Native vegetation', true, false, 0, 'Not supported'], ['Crop rotation', true, false, 1, 'Requires additional evidence']] },
];

const wait = <T,>(v: T) => new Promise<T>(r => setTimeout(() => r(v), 700));
const find = (id: string) => FARMERS.find(f => f.id === id)!;
const st = (d: number): 'ok' | 'warn' | 'bad' => (d <= 8 ? 'ok' : d <= 20 ? 'warn' : 'bad');

/** Prototype implementation: SIMULATED results derived from mock data. */
export class MockVerificationService implements VerificationService {
  async verifyGPS({ farmerId }: GPSVerificationRequest) {
    const f = find(farmerId), areaOk = Math.abs(f.bAc - f.acres) / f.acres < 0.1;
    return wait<GPSVerificationResult>({ lat: f.lat, lng: f.lng, boundaryAcres: f.bAc, accuracyM: f.acc, confidence: f.gpsC, locationOk: f.locOk, checks: [
      { label: 'Coordinates available', ok: true }, { label: 'Coordinates fall inside declared farm region', ok: f.locOk },
      { label: 'Farm boundary area approximately matches submitted area', ok: areaOk }, { label: 'Submission location is geographically consistent', ok: f.locOk }] });
  }
  async analyzeSatellite({ farmerId }: SatelliteAnalysisRequest) {
    const f = find(farmerId), vd = Math.abs(f.vd - f.ve), td = +(Math.abs(f.td - f.te)).toFixed(2);
    return wait<SatelliteAnalysisResult>({ simulated: true, vegDeclared: f.vd, vegEstimated: f.ve, observations: [
      { label: 'Vegetation coverage', claim: `${f.vd}%`, estimate: `${f.ve}%`, diff: `${vd}%`, status: st(vd), note: 'Directly observable' },
      { label: 'Tree / vegetation presence', claim: `${f.td} acre`, estimate: `${f.te} acre`, diff: `${td} acre`, status: st(td * 100 / f.acres * 4), note: 'Directly observable' },
      { label: 'Crop diversity indicator', claim: `${f.claims.length > 2 ? 3 : 2} crop types`, estimate: f.cropEst, diff: '—', status: f.cropOk ? 'ok' : 'warn', note: 'Indicator only' },
      { label: 'Water-related indicator', claim: 'Water-efficient irrigation', estimate: f.waterOk ? 'Consistent with submitted farm data' : 'No supporting indicator', diff: '—', status: f.waterOk ? 'ok' : 'warn', note: 'Requires additional evidence' }] });
  }
  async verifyPractice({ farmerId }: PracticeVerificationRequest) {
    const f = find(farmerId), labels = ['GPS consistency', 'Farm boundary consistency', 'Satellite vegetation consistency', 'Practice evidence'];
    return wait<PracticeVerificationResult>({ rows: f.rows.map(([claim, evidence, gps, sat, result]) => ({ claim, evidence, gps, sat, result })),
      breakdown: labels.map((label, i) => ({ label, value: f.bd[i] })), confidence: f.conf, submittedCredits: f.sub, verifiedCredits: f.ver, heldCredits: f.sub - f.ver });
  }
}
// export class RealVerificationService implements VerificationService { /* fetch('/api/verify/...') */ }
export const verificationService: VerificationService = new MockVerificationService();
