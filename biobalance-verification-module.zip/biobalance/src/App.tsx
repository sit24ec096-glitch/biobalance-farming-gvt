import { useMemo, useState } from 'react';
import { Bell, Cloud, Coins, FileText, Landmark, Home, Map, Menu, Search, Settings as Cog, ShieldCheck, Sprout, Users, Wallet, X } from 'lucide-react';
import { Card, Select } from './components/ui';
import FarmerDetail from './components/FarmerDetail';
import { Credits, Dashboard, Farmers, Incentives, Regional, Scatterplot, Settings } from './pages';
import VerificationCenter from './verification/VerificationCenter';
import { Farm, PERIODS, Period, REGISTRY, REGIONS, kpis } from './data';

const NAV = [['Overview', Home], ['Farmers', Users], ['BioBalance Credits', Coins], ['Biodiversity', Sprout], ['Economic Viability', Wallet],
  ['Incentives', Landmark], ['Regional Analysis', Map], ['Verification', ShieldCheck], ['Reports', FileText], ['Settings', Cog]] as const;

export default function App() {
  const [page, setPage] = useState<string>('Overview');
  const [period, setPeriod] = useState<Period>('Current Season');
  const [region, setRegion] = useState('All India');
  const [demo, setDemo] = useState(true);
  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState<Farm | null>(null);
  const k = useMemo(() => kpis(region, period), [region, period]);
  const registry = region === 'All India' ? REGISTRY : REGISTRY.filter(f => f.region === region);
  const go = (p: string) => { setPage(p); setOpen(false); };

  const body = () => {
    switch (page) {
      case 'Farmers': return <Farmers farms={registry} onOpen={setSel} />;
      case 'BioBalance Credits': case 'Biodiversity': return <Credits />;
      case 'Economic Viability': return <Scatterplot farms={k.sub} />;
      case 'Incentives': return <Incentives onNav={go} />;
      case 'Regional Analysis': return <Regional />;
      case 'Verification': return <VerificationCenter />;
      case 'Settings': return <Settings />;
      case 'Reports': return <Card title="Reports"><p className="text-sm">Use Export Report on the Incentives page to print or save a PDF. Additional report types are not part of this prototype.</p></Card>;
      default: return <Dashboard k={k} />;
    }
  };
  return (
    <div className="flex min-h-screen">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-green-950 p-5 text-green-50 transition-transform lg:static lg:translate-x-0 ${open ? '' : '-translate-x-full'}`}>
        <div className="font-display text-2xl">🌱 BioBalance</div><div className="text-sm text-green-300">Government Portal</div>
        <p className="mt-2 text-xs text-green-200">Rewarding the balance between farmer livelihoods and nature.</p>
        <nav className="mt-6 flex-1 space-y-1">{NAV.map(([n, Icon]) => (
          <button key={n} onClick={() => go(n)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm ${page === n ? 'bg-green-800' : 'hover:bg-green-900'}`}><Icon size={16} />{n}</button>))}</nav>
        <div className="border-t border-green-800 pt-3 text-sm"><b>Government Admin</b><div className="flex items-center gap-1 text-xs text-green-300"><Cloud size={12} />🟢 Cloud data synchronized</div></div>
      </aside>
      <main className="min-w-0 flex-1">
        {demo && <div className="bg-amber-100 px-4 py-1 text-center text-xs font-semibold text-amber-900">Prototype dataset — demonstration only.</div>}
        <header className="flex flex-wrap items-center gap-3 p-4 lg:px-8">
          <button className="lg:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
          <div className="min-w-0 flex-1"><h1 className="font-display text-2xl text-green-950">🏛️ BioBalance Government Portal</h1>
            <p className="text-sm text-stone-600">Agricultural Sustainability &amp; Biodiversity Monitoring System</p></div>
          <Search size={18} /><Bell size={18} /><span className="rounded-full bg-green-800 px-3 py-1 text-sm text-white">Admin</span>
        </header>
        <div className="flex flex-wrap items-center gap-4 px-4 pb-4 lg:px-8">
          <Select label="Monitoring Period" value={period} options={Object.keys(PERIODS)} onChange={v => setPeriod(v as Period)} />
          <Select label="Region" value={region} options={['All India', ...REGIONS]} onChange={setRegion} />
          <button onClick={() => setDemo(!demo)} className={`rounded-full px-3 py-1 text-sm ${demo ? 'bg-amber-500 text-white' : 'bg-stone-200'}`}>Demo Mode</button>
        </div>
        <div className="px-4 pb-10 lg:px-8">{body()}</div>
      </main>
      {sel && <FarmerDetail farm={sel} onClose={() => setSel(null)} />}
    </div>
  );
}
